from main_app import MainApp

if __name__ == "__main__":
    app = MainApp()
    app.mainloop()
#python3 /home/pi/Python_view_game/SaimonSay/main.py &
